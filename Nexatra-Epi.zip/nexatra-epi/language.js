const params=new URLSearchParams(location.search);const lang=params.get("lang")||"jepang";
const data={
jepang:{name:"Jepang",flag:"🇯🇵",desc:"Mulai dari huruf sampai percakapan sehari-hari.",topics:["Kosa kata sehari-hari","Vokal AIUEO","Kotoba","Hiragana","Katakana","Kanji","Pemahaman bahasa","Cara penggunaan","TTS Jepang"],items:[["Ohayou","おはよう","Selamat pagi"],["Arigatou","ありがとう","Terima kasih"],["Mizu","みず","Air"],["Tabemasu","たべます","Makan"]],quiz:["Apa arti ありがとう?","Terima kasih",["Selamat pagi","Terima kasih","Sampai jumpa","Air"]]},
arab:{name:"Bahasa Arab",flag:"ع",desc:"Kosakata, angka, ungkapan, dan latihan dasar.",topics:["Kosakata Arab","Angka 1–100","Cara bilang","Ungkapan sehari-hari","Membaca Arab","TTS Arab"],items:[["Marhaban","مَرْحَبًا","Halo"],["Syukran","شُكْرًا","Terima kasih"],["Kitab","كِتَاب","Buku"],["Wahid","وَاحِد","Satu"]],quiz:["Apa arti شُكْرًا?","Terima kasih",["Buku","Satu","Terima kasih","Halo"]]},
inggris:{name:"Inggris",flag:"🇬🇧",desc:"Vocabulary, grammar, percakapan, dan latihan.",topics:["Ribuan vocabulary","Kosa kata sehari-hari","Grammar","TTS Inggris","Conversation","Kuis & soal"],items:[["Hello","hello","Halo"],["Thank you","thank you","Terima kasih"],["Book","book","Buku"],["Water","water","Air"]],quiz:["Apa arti 'water'?","Air",["Buku","Makan","Air","Halo"]]},
china:{name:"China",flag:"中",desc:"Mandarin dasar dengan hanzi, pinyin, dan percakapan.",topics:["Kosa kata sehari-hari","Hanzi","Pinyin","Nada Mandarin","Angka","TTS Mandarin","Kuis & soal"],items:[["Ni hao","你好","Halo"],["Xie xie","谢谢","Terima kasih"],["Shui","水","Air"],["Yi","一","Satu"]],quiz:["Apa arti 谢谢?","Terima kasih",["Halo","Buku","Terima kasih","Satu"]]}
}[lang]||null;
if(!data){location.href="index.html"}else{
document.title=`Nexatra Epi — ${data.name}`;title.textContent=`${data.flag} Belajar ${data.name}`;desc.textContent=data.desc;
tabs.innerHTML=data.topics.map((x,i)=>`<button class="tab ${i===0?"active":""}" onclick="showTopic('${x}',this)">${x}</button>`).join("");
showTopic(data.topics[0],document.querySelector(".tab"));
}
function showTopic(topic,el){document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));el.classList.add("active");
let html=`<div class="lesson-grid"><article class="lesson"><h3>${topic}</h3><p>Materi interaktif ${data.name} untuk topik <b>${topic}</b>. Gunakan kartu di bawah untuk berlatih.</p></article>`;
data.items.forEach(x=>html+=`<article class="lesson"><div class="flash">${x[0]}</div><p><b>${x[1]}</b> — ${x[2]}</p><div class="tts"><button class="btn" onclick="speak('${x[1]}','${lang}')">🔊 Dengarkan</button></div></article>`);
html+=`</div><div class="quiz"><h2>🎯 Latihan cepat</h2><p><b>${data.quiz[0]}</b></p><div class="answers">${data.quiz[2].map(a=>`<button class="btn" onclick="check(this,'${a.replace(/'/g,"\\'")}','${data.quiz[1]}')">${a}</button>`).join("")}</div><p id="result"></p></div>`;
content.innerHTML=html}
function check(btn,a,c){result.textContent=a===c?"✅ Benar!":"❌ Belum tepat. Coba lagi.";result.style.fontWeight="900"}
function speak(text,lang){if(!("speechSynthesis" in window)){alert("Browser ini belum mendukung TTS.");return}const u=new SpeechSynthesisUtterance(text);u.lang={jepang:"ja-JP",arab:"ar-SA",inggris:"en-US",china:"zh-CN"}[lang];speechSynthesis.cancel();speechSynthesis.speak(u)}
