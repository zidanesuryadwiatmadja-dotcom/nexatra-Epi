# Nexatra Epi
Website pembelajaran statis.

## Jalankan
Buka `index.html` di browser, atau upload seluruh folder ke GitHub Pages/Vercel.

## Fitur
- Dashboard 5 kartu transparan dengan border hitam 4px + shadow.
- Halaman Jepang, Arab, Inggris, China.
- Materi contoh, kartu kosakata, kuis, dan Web Speech API untuk TTS.
- Al-Qur'an memakai Al Quran Cloud API untuk daftar 114 surah dan teks/terjemahan.
- Responsive untuk HP.

Catatan: API Al Quran Cloud menyatakan jumlah ayat yang digunakan API adalah 6.236, bukan 6.666. Website mengikuti data API tersebut.
